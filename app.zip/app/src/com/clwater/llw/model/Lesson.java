package com.clwater.llw.model;

public class Lesson {
	String student_id,student_name,attendance,lessonstatu,homework,lessontest,score;

	public String getStudent_id() {
		return student_id;
	}

	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getAttendance() {
		return attendance;
	}

	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}

	public String getLessonstatu() {
		return lessonstatu;
	}

	public void setLessonstatu(String lessonstatu) {
		this.lessonstatu = lessonstatu;
	}

	public String getHomework() {
		return homework;
	}

	public void setHomework(String homework) {
		this.homework = homework;
	}

	public String getLessontest() {
		return lessontest;
	}

	public void setLessontest(String lessontest) {
		this.lessontest = lessontest;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}
}
