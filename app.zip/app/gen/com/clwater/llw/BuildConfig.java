/** Automatically generated file. DO NOT MODIFY */
package com.clwater.llw;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}